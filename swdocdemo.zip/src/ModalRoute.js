import React from 'react';
import {levels} from './Levels';

// export const MakeModalHistory = (which) => {
//     let modalHistory = [];
//     modalHistory.push(which);
//     console.log(modalHistory);
// }

// for(let i = 0; i < levels.length; i++){
//     if(levels[i].title != 'ROOTLEVEL'){
//         var levelTitle1 = levels[i].title.split(' ').join('');
//         var levelPath = "/" + levelTitle1
//         console.log(levelPath);
//     }
// }

// export default ModalRoute = () => {
//     for(let i = 0; i > levels.length; i++){
//         if(levels[i].file == undefined){
//             levels[i].title.join(" ");
//         }
//     }
// }
