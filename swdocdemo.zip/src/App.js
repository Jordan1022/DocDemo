import logo from './logo.svg';
import ModalParent from './ModalParent';
//
import './App.css';
import TextComponent from './TextComponent';

function App() {
  
  return (
    <div className="App">
      <ModalParent />
    </div>
  );
}

export default App;
