const text = `
<style>
.red {
    color:black;
}
</style>
<span class="red">A #|0|# is used by an #|1|# of
the #|Sweet Economy|#, or simply the #|Economy|#,
to define their wishes concerning the distribution of their #|owned|# SWEETSQUARES,
or simply <LinkPreview />, upon their death. <LinkPreview /> requires
each <LinkPreview text="iCitizen" href="#icitizen" /> to <LinkPreview text="explicitly" href="#explicitly" /> define and declare
their beneficiaries,</span>`;
export default text;