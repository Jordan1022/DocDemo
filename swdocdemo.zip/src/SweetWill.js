import React from 'react';
import ModalParent from './ModalParent';
import TextComponent from './TextComponent';

export default function SweetWill() {
    
    return(
        <>
        <ModalParent />
        <TextComponent />
        </>
    );
}